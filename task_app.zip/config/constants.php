<?php
return [
    'status_values' => array(1=>'Assigned', 2=>'Pending', 3=>'Completed', 4=>'Canceled'),
	'user_roles' => array(1=>'Admin', 2=>'Staff'),
	'user_roles_staff' =>2,
];
?>
<?php $__env->startSection('content'); ?>

<div class="jumbotron main-section">
			
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<h1>Create Task</h1>
			<form method="post" action="<?php echo e(route('task.store')); ?>">
				@csrf
				<div class="form-group">
					<label for="exampleInputEmail1">Task</label>
					<input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter task">
				</div>
				<div class="form-group">
					<label for="exampleInputEmail1">Descrition</label>
					<input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter Descrition">
				</div>
				<div class="form-group">
					<label for="exampleInputEmail1">Date</label>
					<input type="text" class="form-control" id="exampleInputEmail1" placeholder="Select Date">
				</div>
				<div class="form-group">
					<label for="exampleInputEmail1">Assigned to</label>
					<select id="inputState" class="form-control">
						<option selected>Choose...</option>
						<option value="1">Test</option>
					</select>
				</div>
				<button type="submit" class="btn btn-primary">Submit</button>
			</form>
		</div>
	</div>
	<!-- Table End -->

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="jumbotron col-md-8 col-md-offset-2 main-section">
	<h1>Hai Admin</h1>
	<p class="lead">Please see the below list of your assiged tasks.</p>

		<!-- Table Start -->
		<table class="table table-hover Mtop20">
			<thead>
				<tr>
				  <th scope="col">#</th>
				  <th scope="col">Task</th>
				  <th scope="col">Description</th>
				  <th scope="col">Date</th>
				  <th scope="col">Status</th>
				  <th scope="col"></th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach($model as $row){
					?>
					<tr>
					  <th scope="row">1</th>
					  <td><?php echo e($row->task); ?></td>
					  <td><?php echo e($row->description); ?></td>
					  <td><?php echo e($row->end_date); ?></td>
					  <td><?php echo e($row->status); ?></td>
					  <td>
							<img src="assets/images/view.png" alt="icon name">
							<img src="assets/images/edit.png" alt="icon name">
							<img src="assets/images/delete.png" alt="icon name">
					  </td>
					</tr>
					<?php
				}
				?>
				
			</tbody>
		</table>
		<!-- Table End -->

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
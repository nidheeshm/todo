<?php $__env->startSection('content'); ?>
<div class="jumbotron main-section">
			
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<h1>Create Task</h1>
			<?php if($errors->any()): ?>
			  <div class="alert alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					  <li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			  </div><br />
			<?php endif; ?>
			<form method="post" action="<?php echo e(route('task.store')); ?>">
				<?php echo e(csrf_field()); ?>

				<div class="form-group">
					<label for="exampleInputEmail1">Task</label>
					<input type="text" class="form-control" name="task" placeholder="Enter task" value="<?php echo e(old('task')); ?>">
				</div>
				<div class="form-group">
					<label for="exampleInputEmail1">Descrition</label>
					<input type="text" class="form-control" name="description" placeholder="Enter Descrition" value="<?php echo e(old('description')); ?>">
				</div>
				<div class="form-group">
					<label for="exampleInputEmail1">Start Date</label>
					<input type="text" class="form-control date" name="start_date" placeholder="Select Start Date" value="<?php echo e(old('start_date')); ?>">
				</div>
				<div class="form-group">
					<label for="exampleInputEmail1">End Date</label>
					<input type="text" class="form-control date" name="end_date" placeholder="Select End Date" value="<?php echo e(old('end_date')); ?>">
				</div>
				<div class="form-group">
					<label for="exampleInputEmail1">Assigned to</label>
					<select id="inputState" name="assigned_to" class="form-control">
						<option selected>Choose...</option>
						<?php
						foreach($users as $row){
							?>
							<option  value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
							<?php
						}
						?>
					</select>
				</div>
				<input type="submit" class="btn btn-primary" value="Save">
			</form>
		</div>
	</div>
	<!-- Table End -->

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="jumbotron main-section col-md-10 col-md-offset-1">
			
		<h1><?php echo e($task->task); ?></h1>

		<!-- Table Start -->
		<table class="table table-bordered">
			<tbody>
				<tr>
				  <th scope="row">Description</th>
				  <td><?php echo e($task->description); ?></td>
				</tr>
				<tr>
				  <th scope="row">Start Date</th>
				  <td colspan="2"><?php echo e(date('d-M-Y', strtotime($task->start_date))); ?></td>
				</tr>
				<tr>
				  <th scope="row">End Date</th>
				  <td colspan="2"><?php echo e(date('d-M-Y', strtotime($task->end_date))); ?></td>
				</tr>
				<tr>
				  <th scope="row">Status</th>
				  <td colspan="2"><?php echo e(isset($status[$task->status]) ? $status[$task->status] : ''); ?></td>
				</tr>
			</tbody>
		</table>
		<!-- Table End -->

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>